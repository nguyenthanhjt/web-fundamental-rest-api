export class CreateServiceDto {}
